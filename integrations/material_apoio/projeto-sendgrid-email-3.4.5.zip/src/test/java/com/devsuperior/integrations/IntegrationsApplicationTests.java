package com.devsuperior.integrations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntegrationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
