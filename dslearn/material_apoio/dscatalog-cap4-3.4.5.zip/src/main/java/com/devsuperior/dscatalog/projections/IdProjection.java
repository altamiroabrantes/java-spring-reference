package com.devsuperior.dscatalog.projections;

public interface IdProjection<E> {

	E getId();
}
